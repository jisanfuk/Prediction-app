from sklearn.tree import DecisionTreeClassifier
import joblib

X = [[1,1,1,1], [0,0,0,0], [1,0,1,0], [0,1,0,1], [1,1,0,0], [0,0,1,1]]
y = ['BIG','SMALL','BIG','SMALL','BIG','SMALL']

clf = DecisionTreeClassifier()
clf.fit(X, y)
joblib.dump(clf, 'predictor.joblib')